"use client"

import { useEffect, useRef, useState } from "react"
import jsQR from "jsqr"

interface QrScannerProps {
  onScan: (data: string | null) => void
  width?: number
  height?: number
  scanInterval?: number
}

export default function QrScanner({ onScan, width = 300, height = 300, scanInterval = 100 }: QrScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const video = videoRef.current
    const canvas = canvasRef.current
    if (!video || !canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrameId: number
    let intervalId: NodeJS.Timeout

    // Start the camera
    navigator.mediaDevices
      .getUserMedia({ video: { facingMode: "environment" } })
      .then((stream) => {
        video.srcObject = stream
        video.play()

        // Set up scanning interval
        intervalId = setInterval(() => {
          if (video.readyState === video.HAVE_ENOUGH_DATA) {
            // Draw video frame to canvas
            canvas.width = width
            canvas.height = height
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

            // Get image data for QR code scanning
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)

            // Scan for QR code
            const code = jsQR(imageData.data, imageData.width, imageData.height, {
              inversionAttempts: "dontInvert",
            })

            // If QR code found, call onScan callback
            if (code) {
              onScan(code.data)
            }
          }
        }, scanInterval)
      })
      .catch((err) => {
        setError("Camera access denied or not available")
        console.error("Error accessing camera:", err)
      })

    // Draw scanning animation
    const drawScanAnimation = () => {
      if (!ctx) return

      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw video frame
      if (video.readyState === video.HAVE_ENOUGH_DATA) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
      }

      // Draw scanning overlay
      ctx.strokeStyle = "#00FF00"
      ctx.lineWidth = 4
      ctx.beginPath()
      const size = Math.min(canvas.width, canvas.height) * 0.6
      const x = (canvas.width - size) / 2
      const y = (canvas.height - size) / 2
      ctx.rect(x, y, size, size)
      ctx.stroke()

      animationFrameId = requestAnimationFrame(drawScanAnimation)
    }

    drawScanAnimation()

    // Cleanup
    return () => {
      if (intervalId) clearInterval(intervalId)
      if (animationFrameId) cancelAnimationFrame(animationFrameId)
      if (video.srcObject) {
        const tracks = (video.srcObject as MediaStream).getTracks()
        tracks.forEach((track) => track.stop())
      }
    }
  }, [onScan, width, height, scanInterval])

  return (
    <div className="relative w-full h-full">
      <video ref={videoRef} className="absolute top-0 left-0 w-full h-full object-cover invisible" />
      <canvas ref={canvasRef} className="w-full h-full" />
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-white p-4 text-center">
          {error}
        </div>
      )}
    </div>
  )
}

