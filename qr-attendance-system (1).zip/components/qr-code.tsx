"use client"

import { useEffect, useRef } from "react"
import QRCodeLib from "qrcode"

interface QRCodeProps {
  value: string
  size?: number
  level?: "L" | "M" | "Q" | "H"
  bgColor?: string
  fgColor?: string
}

export default function QRCode({
  value,
  size = 200,
  level = "M",
  bgColor = "#ffffff",
  fgColor = "#000000",
}: QRCodeProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const options = {
      errorCorrectionLevel: level,
      margin: 4,
      width: size,
      color: {
        dark: fgColor,
        light: bgColor,
      },
    }

    QRCodeLib.toCanvas(canvasRef.current, value, options, (error) => {
      if (error) console.error("Error generating QR code:", error)
    })
  }, [value, size, level, bgColor, fgColor])

  return (
    <div className="flex justify-center">
      <canvas ref={canvasRef} />
    </div>
  )
}

