"use client"

import { useEffect, useRef } from "react"
import Chart from "chart.js/auto"

interface AttendanceSummaryChartProps {
  attendanceRecords: any[]
  employees: any[]
}

export default function AttendanceSummaryChart({ attendanceRecords, employees }: AttendanceSummaryChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null)
  const chartInstance = useRef<Chart | null>(null)

  useEffect(() => {
    if (!chartRef.current) return

    // Destroy previous chart if it exists
    if (chartInstance.current) {
      chartInstance.current.destroy()
    }

    // Get the last 7 days
    const today = new Date()
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date(today)
      date.setDate(date.getDate() - i)
      return date.toISOString().split("T")[0]
    }).reverse()

    // Calculate attendance for each day
    const attendanceData = last7Days.map((date) => {
      const recordsForDay = attendanceRecords.filter((record) => record.date === date)
      const presentCount = new Set(
        recordsForDay.filter((record) => record.checkInTime).map((record) => record.employeeId),
      ).size
      const lateCount = recordsForDay.filter((record) => {
        if (!record.checkInTime) return false
        const checkInTime = new Date(record.checkInTime)
        const nineAM = new Date(date)
        nineAM.setHours(9, 0, 0)
        return checkInTime > nineAM
      }).length

      return {
        date,
        presentCount,
        lateCount,
        absentCount: employees.length - presentCount,
      }
    })

    // Format dates for display
    const formattedDates = last7Days.map((date) => {
      const d = new Date(date)
      return d.toLocaleDateString("en-US", { month: "short", day: "numeric" })
    })

    // Create chart
    const ctx = chartRef.current.getContext("2d")
    if (!ctx) return

    chartInstance.current = new Chart(ctx, {
      type: "bar",
      data: {
        labels: formattedDates,
        datasets: [
          {
            label: "Present",
            data: attendanceData.map((d) => d.presentCount),
            backgroundColor: "rgba(34, 197, 94, 0.7)",
            borderColor: "rgba(34, 197, 94, 1)",
            borderWidth: 1,
          },
          {
            label: "Late",
            data: attendanceData.map((d) => d.lateCount),
            backgroundColor: "rgba(245, 158, 11, 0.7)",
            borderColor: "rgba(245, 158, 11, 1)",
            borderWidth: 1,
          },
          {
            label: "Absent",
            data: attendanceData.map((d) => d.absentCount),
            backgroundColor: "rgba(239, 68, 68, 0.7)",
            borderColor: "rgba(239, 68, 68, 1)",
            borderWidth: 1,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            stacked: true,
          },
          y: {
            stacked: true,
            beginAtZero: true,
            ticks: {
              precision: 0,
            },
          },
        },
      },
    })

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy()
      }
    }
  }, [attendanceRecords, employees])

  return (
    <div className="w-full h-[300px]">
      <canvas ref={chartRef} />
    </div>
  )
}

