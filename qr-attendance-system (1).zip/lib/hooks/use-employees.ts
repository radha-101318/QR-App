"use client"

import { useState, useEffect } from "react"

interface Employee {
  id: string
  name: string
  email: string
  department: string
  position: string
  qrCode: string
  createdAt: string
}

export function useEmployees() {
  const [employees, setEmployees] = useState<Employee[]>([])

  // Load employees from localStorage on mount
  useEffect(() => {
    const storedEmployees = localStorage.getItem("employees")
    if (storedEmployees) {
      try {
        setEmployees(JSON.parse(storedEmployees))
      } catch (error) {
        console.error("Failed to parse employees from localStorage:", error)
      }
    }
  }, [])

  // Save employees to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("employees", JSON.stringify(employees))
  }, [employees])

  // Add a new employee
  const addEmployee = (employee: Employee) => {
    setEmployees((prev) => [...prev, employee])
  }

  // Update an existing employee
  const updateEmployee = (id: string, updatedEmployee: Partial<Employee>) => {
    setEmployees((prev) => prev.map((emp) => (emp.id === id ? { ...emp, ...updatedEmployee } : emp)))
  }

  // Delete an employee
  const deleteEmployee = (id: string) => {
    setEmployees((prev) => prev.filter((emp) => emp.id !== id))
  }

  // Get an employee by ID
  const getEmployee = (id: string) => {
    return employees.find((emp) => emp.id === id)
  }

  return {
    employees,
    addEmployee,
    updateEmployee,
    deleteEmployee,
    getEmployee,
  }
}

