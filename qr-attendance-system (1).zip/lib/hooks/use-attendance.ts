"use client"

import { useState, useEffect } from "react"

interface AttendanceRecord {
  id: string
  employeeId: string
  date: string
  checkInTime?: string
  checkOutTime?: string
}

export function useAttendance() {
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([])

  // Load attendance records from localStorage on mount
  useEffect(() => {
    const storedRecords = localStorage.getItem("attendanceRecords")
    if (storedRecords) {
      try {
        setAttendanceRecords(JSON.parse(storedRecords))
      } catch (error) {
        console.error("Failed to parse attendance records from localStorage:", error)
      }
    }
  }, [])

  // Save attendance records to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("attendanceRecords", JSON.stringify(attendanceRecords))
  }, [attendanceRecords])

  // Record attendance (check-in or check-out)
  const recordAttendance = (record: AttendanceRecord) => {
    // Check if there's an existing record for this employee on this date
    const existingRecordIndex = attendanceRecords.findIndex(
      (r) => r.employeeId === record.employeeId && r.date === record.date,
    )

    if (existingRecordIndex >= 0) {
      // Update existing record (likely adding check-out time)
      const updatedRecords = [...attendanceRecords]
      updatedRecords[existingRecordIndex] = {
        ...updatedRecords[existingRecordIndex],
        ...record,
        id: updatedRecords[existingRecordIndex].id, // Keep the original ID
      }
      setAttendanceRecords(updatedRecords)
    } else {
      // Add new record
      setAttendanceRecords((prev) => [...prev, record])
    }
  }

  // Get the last attendance record for an employee
  const getLastAttendance = (employeeId: string) => {
    const employeeRecords = attendanceRecords
      .filter((record) => record.employeeId === employeeId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

    return employeeRecords[0] || null
  }

  // Get attendance records for a specific date
  const getAttendanceByDate = (date: string) => {
    return attendanceRecords.filter((record) => record.date === date)
  }

  // Get attendance records for a specific employee
  const getAttendanceByEmployee = (employeeId: string) => {
    return attendanceRecords.filter((record) => record.employeeId === employeeId)
  }

  return {
    attendanceRecords,
    recordAttendance,
    getLastAttendance,
    getAttendanceByDate,
    getAttendanceByEmployee,
  }
}

