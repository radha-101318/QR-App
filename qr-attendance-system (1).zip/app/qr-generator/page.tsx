"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Download, Printer } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useEmployees } from "@/lib/hooks/use-employees"
import QRCode from "@/components/qr-code"

export default function QRGeneratorPage() {
  const { toast } = useToast()
  const searchParams = useSearchParams()
  const { employees } = useEmployees()
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string>("")
  const [selectedEmployee, setSelectedEmployee] = useState<any>(null)

  useEffect(() => {
    const employeeId = searchParams.get("employeeId")
    if (employeeId) {
      setSelectedEmployeeId(employeeId)
      const employee = employees.find((emp) => emp.id === employeeId)
      if (employee) {
        setSelectedEmployee(employee)
      }
    }
  }, [searchParams, employees])

  const handleEmployeeChange = (value: string) => {
    setSelectedEmployeeId(value)
    const employee = employees.find((emp) => emp.id === value)
    setSelectedEmployee(employee || null)
  }

  const handleDownload = () => {
    // In a real app, this would download the QR code as an image
    toast({
      title: "QR Code Downloaded",
      description: "The QR code has been downloaded successfully.",
    })
  }

  const handlePrint = () => {
    // In a real app, this would print the QR code
    toast({
      title: "Printing QR Code",
      description: "The QR code is being sent to the printer.",
    })
  }

  return (
    <div className="container mx-auto py-10 px-4">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold tracking-tight">QR Code Generator</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Generate Employee QR Code</CardTitle>
            <CardDescription>
              Select an employee to generate their unique QR code for attendance tracking.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Select Employee</label>
                <Select value={selectedEmployeeId} onValueChange={handleEmployeeChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select an employee" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map((employee) => (
                      <SelectItem key={employee.id} value={employee.id}>
                        {employee.name} - {employee.department}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>QR Code Preview</CardTitle>
            <CardDescription>
              {selectedEmployee
                ? `QR Code for ${selectedEmployee.name}`
                : "Select an employee to preview their QR code"}
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            {selectedEmployee ? (
              <div className="flex flex-col items-center">
                <QRCode value={selectedEmployee.id} size={200} />
                <div className="mt-4 text-center">
                  <p className="font-semibold text-lg">{selectedEmployee.name}</p>
                  <p className="text-muted-foreground">{selectedEmployee.department}</p>
                  <p className="text-muted-foreground">{selectedEmployee.position}</p>
                </div>
              </div>
            ) : (
              <div className="h-[200px] w-[200px] border-2 border-dashed border-muted-foreground/20 rounded-lg flex items-center justify-center">
                <p className="text-muted-foreground text-center px-4">QR code preview will appear here</p>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-center gap-4">
            <Button variant="outline" onClick={handleDownload} disabled={!selectedEmployee}>
              <Download className="mr-2 h-4 w-4" />
              Download
            </Button>
            <Button onClick={handlePrint} disabled={!selectedEmployee}>
              <Printer className="mr-2 h-4 w-4" />
              Print
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

