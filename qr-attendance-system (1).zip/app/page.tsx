import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Clock, QrCode, Users, BarChart3, ArrowRight } from "lucide-react"

export default function Home() {
  return (
    <div className="container mx-auto py-10 px-4">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold tracking-tight">QR Code Attendance System</h1>
        <p className="text-xl text-muted-foreground mt-2">Streamline attendance tracking with QR code technology</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <Card>
          <CardHeader className="space-y-1">
            <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-2">
              <Users className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Employee Management</CardTitle>
            <CardDescription>Register and manage employees</CardDescription>
          </CardHeader>
          <CardFooter>
            <Link href="/employees" className="w-full">
              <Button variant="outline" className="w-full group">
                Manage Employees
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition" />
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="space-y-1">
            <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-2">
              <QrCode className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>QR Code Generation</CardTitle>
            <CardDescription>Create unique QR codes for employees</CardDescription>
          </CardHeader>
          <CardFooter>
            <Link href="/qr-generator" className="w-full">
              <Button variant="outline" className="w-full group">
                Generate QR Codes
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition" />
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="space-y-1">
            <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-2">
              <Clock className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Attendance Scanner</CardTitle>
            <CardDescription>Scan QR codes for check-in/out</CardDescription>
          </CardHeader>
          <CardFooter>
            <Link href="/scanner" className="w-full">
              <Button variant="outline" className="w-full group">
                Open Scanner
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition" />
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="space-y-1">
            <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-2">
              <BarChart3 className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Reports & Analytics</CardTitle>
            <CardDescription>View attendance reports and insights</CardDescription>
          </CardHeader>
          <CardFooter>
            <Link href="/reports" className="w-full">
              <Button variant="outline" className="w-full group">
                View Reports
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition" />
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>

      <div className="mb-10">
        <Card>
          <CardHeader>
            <CardTitle>How It Works</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex flex-col items-center text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                  <span className="text-2xl font-bold text-primary">1</span>
                </div>
                <h3 className="text-lg font-semibold mb-2">Generate QR Codes</h3>
                <p className="text-muted-foreground">
                  Each employee gets a unique QR code linked to their Employee ID.
                </p>
              </div>

              <div className="flex flex-col items-center text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                  <span className="text-2xl font-bold text-primary">2</span>
                </div>
                <h3 className="text-lg font-semibold mb-2">Scan QR Codes</h3>
                <p className="text-muted-foreground">
                  Employees scan their QR codes to check in and out, recording timestamps.
                </p>
              </div>

              <div className="flex flex-col items-center text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                  <span className="text-2xl font-bold text-primary">3</span>
                </div>
                <h3 className="text-lg font-semibold mb-2">View Reports</h3>
                <p className="text-muted-foreground">Admins can access real-time attendance reports and analytics.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="text-center">
        <Link href="/scanner">
          <Button size="lg" className="px-8">
            Get Started
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </Link>
      </div>
    </div>
  )
}

