"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { ArrowLeft, Camera, CheckCircle2, XCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useEmployees } from "@/lib/hooks/use-employees"
import { useAttendance } from "@/lib/hooks/use-attendance"
import QrScanner from "@/components/qr-scanner"

export default function ScannerPage() {
  const { toast } = useToast()
  const { employees } = useEmployees()
  const { recordAttendance, getLastAttendance } = useAttendance()
  const [scanning, setScanning] = useState(false)
  const [scanResult, setScanResult] = useState<null | {
    success: boolean
    employee?: any
    isCheckIn?: boolean
    time?: string
  }>(null)
  const scanTimeout = useRef<NodeJS.Timeout | null>(null)

  const handleScan = (data: string | null) => {
    if (data) {
      // Stop scanning after successful scan
      setScanning(false)

      // Find employee by ID (in a real app, you'd validate the QR code format)
      const employee = employees.find((emp) => emp.id === data)

      if (employee) {
        const lastAttendance = getLastAttendance(employee.id)
        const now = new Date()
        const isCheckIn = !lastAttendance || lastAttendance.checkOutTime

        // Record attendance
        recordAttendance({
          id: Date.now().toString(),
          employeeId: employee.id,
          date: now.toISOString().split("T")[0],
          checkInTime: isCheckIn ? now.toISOString() : undefined,
          checkOutTime: !isCheckIn ? now.toISOString() : undefined,
        })

        // Show success message
        setScanResult({
          success: true,
          employee,
          isCheckIn,
          time: now.toLocaleTimeString(),
        })

        toast({
          title: isCheckIn ? "Check-In Successful" : "Check-Out Successful",
          description: `${employee.name} has been ${isCheckIn ? "checked in" : "checked out"} at ${now.toLocaleTimeString()}.`,
        })
      } else {
        // Show error message for unknown QR code
        setScanResult({
          success: false,
        })

        toast({
          title: "Unknown QR Code",
          description: "The scanned QR code is not associated with any employee.",
          variant: "destructive",
        })
      }

      // Reset scan result after 5 seconds
      scanTimeout.current = setTimeout(() => {
        setScanResult(null)
      }, 5000)
    }
  }

  const toggleScanner = () => {
    setScanning(!scanning)
    if (scanResult) {
      setScanResult(null)
      if (scanTimeout.current) {
        clearTimeout(scanTimeout.current)
      }
    }
  }

  useEffect(() => {
    return () => {
      if (scanTimeout.current) {
        clearTimeout(scanTimeout.current)
      }
    }
  }, [])

  return (
    <div className="container mx-auto py-10 px-4">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold tracking-tight">Attendance Scanner</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>QR Code Scanner</CardTitle>
            <CardDescription>Scan employee QR codes to record attendance check-in and check-out.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="relative aspect-video bg-muted rounded-lg overflow-hidden flex items-center justify-center">
                {scanning ? (
                  <QrScanner onScan={handleScan} />
                ) : (
                  <div className="text-center p-4">
                    <Camera className="mx-auto h-12 w-12 text-muted-foreground mb-2" />
                    <p className="text-muted-foreground">Click "Start Scanning" to activate the camera</p>
                  </div>
                )}
              </div>

              <Button onClick={toggleScanner} className="w-full" variant={scanning ? "destructive" : "default"}>
                {scanning ? "Stop Scanning" : "Start Scanning"}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Scan Results</CardTitle>
            <CardDescription>The latest attendance record will appear here after scanning.</CardDescription>
          </CardHeader>
          <CardContent>
            {scanResult ? (
              scanResult.success ? (
                <Alert className="border-green-500 bg-green-500/10">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                  <AlertTitle className="text-green-500">
                    {scanResult.isCheckIn ? "Check-In Successful" : "Check-Out Successful"}
                  </AlertTitle>
                  <AlertDescription>
                    <div className="mt-2 space-y-1">
                      <p>
                        <strong>Employee:</strong> {scanResult.employee?.name}
                      </p>
                      <p>
                        <strong>Department:</strong> {scanResult.employee?.department}
                      </p>
                      <p>
                        <strong>Time:</strong> {scanResult.time}
                      </p>
                      <p>
                        <strong>Status:</strong> {scanResult.isCheckIn ? "Checked In" : "Checked Out"}
                      </p>
                    </div>
                  </AlertDescription>
                </Alert>
              ) : (
                <Alert variant="destructive">
                  <XCircle className="h-4 w-4" />
                  <AlertTitle>Invalid QR Code</AlertTitle>
                  <AlertDescription>The scanned QR code is not associated with any employee.</AlertDescription>
                </Alert>
              )
            ) : (
              <div className="h-[200px] border-2 border-dashed border-muted-foreground/20 rounded-lg flex items-center justify-center">
                <p className="text-muted-foreground text-center px-4">
                  Scan an employee QR code to see the results here
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

