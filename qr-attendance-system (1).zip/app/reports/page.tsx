"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Calendar, Clock, Download, Filter } from "lucide-react"
import { useAttendance } from "@/lib/hooks/use-attendance"
import { useEmployees } from "@/lib/hooks/use-employees"
import AttendanceSummaryChart from "@/components/attendance-summary-chart"

export default function ReportsPage() {
  const { attendanceRecords } = useAttendance()
  const { employees } = useEmployees()
  const [dateFilter, setDateFilter] = useState("all")
  const [departmentFilter, setDepartmentFilter] = useState("all")

  // Get unique dates from attendance records
  const dates = [...new Set(attendanceRecords.map((record) => record.date))].sort(
    (a, b) => new Date(b).getTime() - new Date(a).getTime(),
  )

  // Get unique departments from employees
  const departments = [...new Set(employees.map((emp) => emp.department))]

  // Filter attendance records based on selected filters
  const filteredRecords = attendanceRecords.filter((record) => {
    const matchesDate = dateFilter === "all" || record.date === dateFilter
    const employee = employees.find((emp) => emp.id === record.employeeId)
    const matchesDepartment = departmentFilter === "all" || (employee && employee.department === departmentFilter)

    return matchesDate && matchesDepartment
  })

  // Calculate statistics
  const totalEmployees = employees.length
  const presentToday = attendanceRecords.filter((record) => {
    const today = new Date().toISOString().split("T")[0]
    return record.date === today && record.checkInTime
  }).length

  const lateToday = attendanceRecords.filter((record) => {
    const today = new Date().toISOString().split("T")[0]
    if (record.date === today && record.checkInTime) {
      const checkInTime = new Date(record.checkInTime)
      const nineAM = new Date(record.date)
      nineAM.setHours(9, 0, 0)
      return checkInTime > nineAM
    }
    return false
  }).length

  const handleExportReport = () => {
    // In a real app, this would generate and download a CSV/PDF report
    alert("Exporting report...")
  }

  return (
    <div className="container mx-auto py-10 px-4">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold tracking-tight">Attendance Reports</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Employees</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <div className="mr-2 text-2xl font-bold">{totalEmployees}</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Present Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <div className="mr-2 text-2xl font-bold">{presentToday}</div>
              <div className="text-muted-foreground">
                {totalEmployees > 0 ? `(${Math.round((presentToday / totalEmployees) * 100)}%)` : "(0%)"}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Late Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <div className="mr-2 text-2xl font-bold">{lateToday}</div>
              <div className="text-muted-foreground">
                {presentToday > 0 ? `(${Math.round((lateToday / presentToday) * 100)}%)` : "(0%)"}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Attendance Summary</CardTitle>
          <CardDescription>Visual representation of attendance data</CardDescription>
        </CardHeader>
        <CardContent>
          <AttendanceSummaryChart attendanceRecords={attendanceRecords} employees={employees} />
        </CardContent>
      </Card>

      <Tabs defaultValue="daily" className="mb-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
          <TabsList>
            <TabsTrigger value="daily">Daily Report</TabsTrigger>
            <TabsTrigger value="employee">Employee Report</TabsTrigger>
          </TabsList>

          <div className="flex flex-wrap gap-2">
            <div className="flex items-center">
              <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by date" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Dates</SelectItem>
                  {dates.map((date) => (
                    <SelectItem key={date} value={date}>
                      {new Date(date).toLocaleDateString()}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center">
              <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
              <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by department" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button variant="outline" onClick={handleExportReport}>
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>

        <TabsContent value="daily" className="mt-0">
          <Card>
            <CardHeader>
              <CardTitle>Daily Attendance Log</CardTitle>
              <CardDescription>Detailed attendance records for all employees</CardDescription>
            </CardHeader>
            <CardContent>
              {filteredRecords.length === 0 ? (
                <div className="text-center py-10">
                  <p className="text-muted-foreground">No attendance records found for the selected filters.</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Employee</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Check-In</TableHead>
                      <TableHead>Check-Out</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRecords.map((record) => {
                      const employee = employees.find((emp) => emp.id === record.employeeId)
                      const checkInTime = record.checkInTime ? new Date(record.checkInTime) : null
                      const checkOutTime = record.checkOutTime ? new Date(record.checkOutTime) : null

                      // Determine status
                      let status = "Absent"
                      let statusColor = "text-red-500"

                      if (checkInTime) {
                        const nineAM = new Date(record.date)
                        nineAM.setHours(9, 0, 0)

                        if (checkInTime <= nineAM) {
                          status = "On Time"
                          statusColor = "text-green-500"
                        } else {
                          status = "Late"
                          statusColor = "text-amber-500"
                        }
                      }

                      return (
                        <TableRow key={record.id}>
                          <TableCell>{new Date(record.date).toLocaleDateString()}</TableCell>
                          <TableCell className="font-medium">{employee?.name || "Unknown"}</TableCell>
                          <TableCell>{employee?.department || "Unknown"}</TableCell>
                          <TableCell>
                            {checkInTime ? (
                              <div className="flex items-center">
                                <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                                {checkInTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                              </div>
                            ) : (
                              "Not checked in"
                            )}
                          </TableCell>
                          <TableCell>
                            {checkOutTime ? (
                              <div className="flex items-center">
                                <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                                {checkOutTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                              </div>
                            ) : (
                              "Not checked out"
                            )}
                          </TableCell>
                          <TableCell className={statusColor}>{status}</TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="employee" className="mt-0">
          <Card>
            <CardHeader>
              <CardTitle>Employee Attendance Summary</CardTitle>
              <CardDescription>Summary of attendance records by employee</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Total Days Present</TableHead>
                    <TableHead>On Time</TableHead>
                    <TableHead>Late</TableHead>
                    <TableHead>Absent</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {employees.map((employee) => {
                    const employeeRecords = attendanceRecords.filter((record) => record.employeeId === employee.id)

                    const daysPresent = new Set(
                      employeeRecords.filter((record) => record.checkInTime).map((record) => record.date),
                    ).size

                    const daysOnTime = new Set(
                      employeeRecords
                        .filter((record) => {
                          if (!record.checkInTime) return false
                          const checkInTime = new Date(record.checkInTime)
                          const nineAM = new Date(record.date)
                          nineAM.setHours(9, 0, 0)
                          return checkInTime <= nineAM
                        })
                        .map((record) => record.date),
                    ).size

                    const daysLate = daysPresent - daysOnTime

                    // Assuming we're tracking for the current month
                    const today = new Date()
                    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)
                    const daysPassed = Math.min(
                      today.getDate(),
                      new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate(),
                    )

                    const daysAbsent = daysPassed - daysPresent

                    return (
                      <TableRow key={employee.id}>
                        <TableCell className="font-medium">{employee.name}</TableCell>
                        <TableCell>{employee.department}</TableCell>
                        <TableCell>{daysPresent}</TableCell>
                        <TableCell className="text-green-500">{daysOnTime}</TableCell>
                        <TableCell className="text-amber-500">{daysLate}</TableCell>
                        <TableCell className="text-red-500">{daysAbsent}</TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

